<?php

$CONFIG['database']['default'] = array(
    'adapter'  => 'mysql',
    'host'     => 'localhost',
    'port'     => '3306',
    'dbuser'   => 'root',
    'dbpass'   => '',
    'dbname'   => 'yuntu',
    'pconnect' => false,
    'charset'  => 'utf8',
    'pre'      => 'meu_'
);
/*
$CONFIG['database']['default'] = array(
    'adapter'  => 'sqlite',
    'dbname'   => 'data/yuntu.sqlite',
    'pre'      => 'meu_'
);*/

//缓存
$CONFIG['cache_engine'] = 'file';
$CONFIG['cache_policy'] = array('life_time' => 900);

$CONFIG['storage_engine'] = 'file';//file 
$CONFIG['img_engine'] = 'imagick';//imagick or gd

$CONFIG['cookie_name'] = 'MPIC_AU';
$CONFIG['cookie_auth_key'] = 'xshg$bd52iqkcybnc89';
//默认请留空
$CONFIG['cookie_domain'] = '';
$CONFIG['img_path_key'] = 'vhzldjgweqwevx';

//安全模式
$CONFIG['safemode'] = false;
?>