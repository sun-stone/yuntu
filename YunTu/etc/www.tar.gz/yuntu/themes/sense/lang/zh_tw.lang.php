<?php
$language['new_photos'] = '最新照片';
$language['new_albums'] = '最新相冊';
$language['all_albums'] = '所有相冊';
$language['new_comment_for_albums'] = '最新相冊評論';
$language['new_comment_for_photos'] = '最新照片評論';

$language['showindexcomment'] = '首頁顯示評論';
$language['showlistbtns'] = '顯示列表控制按鈕';
$language['showalbumsearch'] = '顯示相冊搜索框';
$language['showphotosearch'] = '顯示照片搜索框';
$language['showjiathis'] = '顯示Jiathis分享按鈕';