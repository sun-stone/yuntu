<?php
$language['new_photos'] =  'New photos';
$language['new_albums']   =  'New albums';
$language['all_albums']   =  'All albums';
$language['new_comment_for_albums'] = 'New comments for albums';
$language['new_comment_for_photos'] = 'New comments for photos';

$language['showindexcomment'] = 'Homepage comments';
$language['showlistbtns'] = 'Control buttons';
$language['showalbumsearch'] = 'Album search box';
$language['showphotosearch'] = 'Photo search box';
$language['showjiathis'] = 'Jiathis Share button';