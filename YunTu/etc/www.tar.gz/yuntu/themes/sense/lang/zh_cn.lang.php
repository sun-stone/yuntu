<?php
$language['new_photos'] =  '最新照片';
$language['new_albums']   =  '最新相册';
$language['all_albums']   =  '所有相册';
$language['new_comment_for_albums'] = '最新相册评论';
$language['new_comment_for_photos'] = '最新照片评论';

$language['showindexcomment'] = '首页显示评论';
$language['showlistbtns']     = '显示列表控制按钮';
$language['showalbumsearch']  = '显示相册搜索框';
$language['showphotosearch']  = '显示照片搜索框';
$language['showjiathis']      = '显示Jiathis分享按钮';