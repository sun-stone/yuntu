<?php
$theme_name = '简约';
$theme_copyright = '简约明快风格主题';
$theme_config = array(
    'showindexcomment' => 0,
    'showlistbtns' => 1,
    'showalbumsearch' => 1,
    'showphotosearch' => 1,
    'showjiathis' => 1
);