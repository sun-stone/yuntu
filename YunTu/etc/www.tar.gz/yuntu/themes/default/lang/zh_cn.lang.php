<?php
$language['sel_exists_style'] =  '选择预设样式';
$language['blue']   =  '蓝色';
$language['green']   =  '绿色';
$language['purple'] =  '紫色';
$language['black'] =   '黑色';
$language['brown'] =  '褐色';
$language['style_bodybg'] =   '页面背景色';
$language['style_link_color'] = '超链接颜色';
$language['style_link_hover_color'] = '超链接悬停颜色';
$language['style_header_bg']   =  '头部背景色';
$language['style_header_h1']  =  '头部大标题颜色';
$language['style_headerbottom']    =  '头部底边颜色';
$language['style_settingtxt'] = '用户状态栏颜色';
$language['style_tablinkbg']   =  '选项卡背景色';
$language['style_tablink'] =  '选项卡颜色';
$language['style_tablinkcurrent']  =  '当前选项卡颜色';
$language['style_tablinkhover']    =  '选项卡悬停颜色';
$language['style_tablinkhoverbg']  =  '选项卡悬停背景色';
$language['style_tablinkfrom'] =  '选项卡渐变色1';
$language['style_tablinkto']   =  '选项卡渐变色2';
$language['style_alertcolor']  =  '警告色';
$language['style_titlebg']     =  '标题背景色';
$language['style_titlelabel']  =  '表单Label色';
$language['style_boxborder']   =  '边框颜色';

$language['not_aliable_color']   =  '颜色无效！';