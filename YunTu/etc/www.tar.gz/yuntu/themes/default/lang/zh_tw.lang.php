<?php
$language['sel_exists_style'] = '選擇預設樣式';
$language['blue'] = '藍色';
$language['green'] = '綠色';
$language['purple'] = '紫色';
$language['black'] = '黑色';
$language['brown'] = '褐色';
$language['style_bodybg'] = '頁面背景色';
$language['style_link_color'] = '超鏈接顏色';
$language['style_link_hover_color'] = '超鏈接懸停顏色';
$language['style_header_bg'] = '頭部背景色';
$language['style_header_h1'] = '頭部大標題顏色';
$language['style_headerbottom'] = '頭部底邊顏色';
$language['style_settingtxt'] = '用戶狀態欄顏色';
$language['style_tablinkbg'] = '選項卡背景色';
$language['style_tablink'] = '選項卡顏色';
$language['style_tablinkcurrent'] = '當前選項卡顏色';
$language['style_tablinkhover'] = '選項卡懸停顏色';
$language['style_tablinkhoverbg'] = '選項卡懸停背景色';
$language['style_tablinkfrom'] = '選項卡漸變色1';
$language['style_tablinkto'] = '選項卡漸變色2';
$language['style_alertcolor'] = '警告色';
$language['style_titlebg'] = '標題背景色';
$language['style_titlelabel'] = '表單Label色';
$language['style_boxborder'] = '邊框顏色';

$language['not_aliable_color']   =  '顏色無效！';