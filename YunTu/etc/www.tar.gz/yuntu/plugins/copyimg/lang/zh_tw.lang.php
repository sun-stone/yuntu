<?php
$language = array(
    'copy_to_clipboard' => '拷貝地址到剪切板',
    'img_url' => '圖片地址',
    'ubb_code' => 'ubb代碼',
    'html_code' => 'html代碼',
    'copy_success' => '拷貝成功！ ',
    'copy_sel_img_url' => '拷貝圖片地址',
    'copy_all_urls' => '拷貝所有圖片地址',
    'pls_sel_photo_want_to_copy' => '請選擇需要拷貝地址的圖片！ ',
    'copy_all_to_clipboard'=> '拷貝相冊中所有圖片地址到剪貼板',
    'available_tags' => '可用的標籤',
    'thumb_path' => '縮略圖地址',
    'img_path' => '原圖地址',
    'detailurl' => '圖片詳情頁URL',
    'img_name' => '圖片名稱',
    'custom_tpl' => '自定義代碼模板',
    'split_tpl' => '照片分隔代碼'
);