<?php
$language = array(
     'copy_to_clipboard' => 'Copy the URL to the clipboard',
     'img_url' => 'Photo URL',
     'ubb_code' => 'Ubb code',
     'html_code' => 'Html code',
     'copy_success' =>' Copy success!',
     'copy_all_urls' => 'Copy all URLs',
     'copy_sel_img_url' => 'Copy the URLs',
     'pls_sel_photo_want_to_copy' => 'Please select a picture to copy! ',
     'copy_all_to_clipboard' => 'Copy of all pictures URL of the album to clipboard',
     'available_tags' => 'Labels available',
     'thumb_path' => 'Thumbnail URL',
     'img_path' => 'Original URL',
     'detailurl' => 'Detail page URL',
     'img_name' => 'Photo name',
     'custom_tpl' => 'Custom code',
     'split_tpl' => 'Separated code',
);