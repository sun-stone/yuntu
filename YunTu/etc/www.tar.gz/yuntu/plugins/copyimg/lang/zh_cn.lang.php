<?php
$language   =  array(
    'copy_to_clipboard' =>  '拷贝地址到剪切板',
    'img_url'   =>  '图片地址',
    'ubb_code'   =>  'ubb代码',
    'html_code' =>  'html代码',
    'copy_success' =>   '拷贝成功！',
    'copy_sel_img_url' => '拷贝图片地址',
    'copy_all_urls' => '拷贝所有图片地址',
    'pls_sel_photo_want_to_copy' => '请选择需要拷贝地址的图片！',
    'copy_all_to_clipboard'=>   '拷贝相册中所有图片地址到剪贴板',
    'available_tags' => '可用的标签',
    'thumb_path' => '缩略图地址',
    'img_path' => '原图地址',
    'detailurl' => '图片详情页URL',
    'img_name' => '图片名称',
    'custom_tpl' => '自定义代码模板',
    'split_tpl' => '照片分隔代码'
);