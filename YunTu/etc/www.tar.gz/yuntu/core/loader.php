<?php

if (PHPVer < 5){
    require(COREDIR.'loader/loader.php4.php');
}else{
    require(COREDIR.'loader/loader.php5.php');
}