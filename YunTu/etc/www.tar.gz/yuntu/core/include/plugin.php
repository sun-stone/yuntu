<?php
/**
 * $Id: plugin.php $
 * plugin base class
 */
class plugin{
    var $config = array();
    
    function plugin($config = null){
        if(!is_null($config)){
            $this->config = array_merge($this->config, $config);
        }
        $this->db =& loader::database();
        $this->plugin_mgr =& loader::lib('plugin');
    }
    
    function init(){
        ;
    }
    function callback_install(){
        ;
    }
    function callback_enable(){
        ;
    }
    function callback_disable(){
        ;
    }
    function callback_remove(){
        ;
    }
    function save_config($posts){
        ;
    }
}