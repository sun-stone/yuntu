<?php
/**
 * $Id: output.class.php 150 2011-05-13 05:11:43Z $
 *
 */

class output_cla{
    var $data = array();
    
    function set($key,$value){
        $this->data[$key] = $value;
    }
    
    function get($key = ''){
        if(!$key) return $this->data;
        else  return isset($this->data[$key]) ? $this->data[$key] : '';
    }
    
    function getAll(){
        return $this->data;
    }
}